import React, { Component } from 'react';
import Articles from './Articles.js';
class ListOfArticles extends Component {
  constructor(props) {
      super(props);
      this.state = { isOpened: false };
  }



  render() {
    return <div><Articles/></div>;
  }
}

export default ListOfArticles;
