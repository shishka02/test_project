import React, { Component } from 'react';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";

class Articles extends Component {
  constructor(props) {
      super(props);
      this.state = {

        firstArticle:{
          user:'Daniel',
          Article:'Daniels text',
          text:<div>daniels text</div>
        },
        secondArticle:{
          user:'Batman',
          Article:'Batmans text',
          text:<div>Batmans text</div>
        },
        thirdArticle:{
          user:'Daniel',
          Article:'Daniels second text',
          text:<div>Daniels second</div>
        },
       }
  }




  render() {

    const linksFromArticle=Object.keys(this.state).map((names)=><li key={names} >{names}</li>);

    console.log(this.state);
    return <div>{linksFromArticle}</div>;
  }
}

export default Articles;
