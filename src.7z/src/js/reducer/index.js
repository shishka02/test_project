const initialState = {
  articles: []
};
const rootReducer = (state = initialState, action) => state;
export default rootReducer;
