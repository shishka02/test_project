import React, { Component } from 'react';

class Header extends Component {
  constructor(props) {
      super(props);
      this.state = { isOpened: false };
  }

  render() {
    return <div>future Header</div>;
  }
}

export default Header;
